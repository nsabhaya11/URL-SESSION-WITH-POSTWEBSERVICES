//
//  ViewController.swift
//  urlsessionwithpostwebservies
//
//  Created by MACOS on 11/26/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit



class ViewController: UIViewController, URLSessionDelegate {

    
    
    
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtmob: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    @IBAction func insetdata(_ sender: AnyObject) {
        
        let str = "http://localhost/crime/insertpost.php"
        let url =  URL(string: str);
        
        let body  = "emp_name=\(txtempname.text!)&emp_add=\(txtempadd.text!)&emp_mob =\(txtmob.text!)";
        
        let data1  =   body.data(using: String.Encoding.utf8)
        
        
    
       
        var requet = URLRequest(url: url!);
        
        requet.addValue(String( body.characters.count) , forHTTPHeaderField: "Content-Length");
        requet.httpBody = data1;
        requet.httpMethod = "POST";
        let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        
        let task = session.dataTask(with: requet) { (data, responce, err) in
            
            let resp = String(data: data!, encoding: String.Encoding.utf8)
            
            print(resp);
            
            
            
        }
        
        task.resume();

        
    }
    
    @IBAction func getdata(_ sender: AnyObject) {
       
       
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

